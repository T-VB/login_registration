from flask import render_template, request, redirect, session, flash
from flask_app import app
from flask_app.models.user import User
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)

@app.route('/')
def index():
    if 'user_id' not in session:
        return render_template('index.html')
    return redirect('/dashboard')

#add route to process the registration, redirecting back to home page once clicked
@app.route('/register', methods=["POST"])
def register():
    if not User.validate_registration(request.form):
        return redirect ('/')
    else:
        #create data object to hash password
        data = {
            'first_name': request.form['first_name'],
            'last_name': request.form['last_name'],
            'email': request.form['email'],
            'password': bcrypt.generate_password_hash(request.form['password'])
        }
        id = User.save(data)
        if not id:
            flash("Error", 'register')
            return redirect('/')
        else:
            session['user_id'] = id
            flash("You logged in successfully", 'register')
        return redirect('/dashboard')

@app.route('/login', methods=["POST"])
def login():
    user = User.get_one_by_email(request.form)
    if not user:
        flash("email not registered", "login")
        return redirect('/')
    #match login info from db to user input
    if not bcrypt.check_password_hash(user.password, request.form['password']):
        flash("password incorrect", "login")
        return redirect('/')
    else:
        session['user_id'] = user.id
        return redirect('/dashboard')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        #if user not in session, redirect to logout process
        return redirect('/logout')
    else:
        data = {
        'id': session ['user_id']
    }
    return render_template('dashboard.html', user=User.get_one(data))

#logout = clearing out session
@app.route('/logout')
def logout():
    session.clear()
#takes user back to login
    return redirect('/')
